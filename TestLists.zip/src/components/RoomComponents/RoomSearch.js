import React, { Component } from 'react';
import { LISTROOMS } from './listRooms';

class RoomSearch extends Component {
  constructor() {
    super();
    this.state = {
      searchTerm: '',
      searchResult: null,
      minPrice: '',
      maxPrice: '',
      filteredRooms: [],
      selectedRoom: null,
    };
  }

  handleSearchInputChange = (event) => {
    this.setState({ searchTerm: event.target.value });
  };

  handleSearch = () => {
    const { searchTerm,tagSearch  } = this.state;
    const searchResult = this.searchRoomByRoomNumber(searchTerm,tagSearch);

    this.setState({ searchResult });
  };

  handleMinPriceChange = (event) => {
    this.setState({ minPrice: event.target.value }, this.filterRooms);
  };

  handleMaxPriceChange = (event) => {
    this.setState({ maxPrice: event.target.value }, this.filterRooms);
  };
  handleTagSearchChange = (event) => {
    this.setState({ tagSearch: event.target.value });
  };

  filterRooms = () => {
    const { minPrice, maxPrice } = this.state;
    const filteredRooms = this.filterRoomsByPrice(minPrice, maxPrice);
    this.setState({ filteredRooms });
    const { tagSearch } = this.state;
    const filteredRoomsByTag = tagSearch
    ? filteredRooms.filter((room) =>
        room.tags.some((tag) => tag.toLowerCase().includes(tagSearch.toLowerCase()))
      )
    : filteredRooms;

  this.setState({ filteredRooms: filteredRoomsByTag });
  };

  filterRoomsByPrice = (minPrice, maxPrice) => {
    return LISTROOMS.filter((room) => {
      const price = room.price;
      return price >= minPrice && price <= maxPrice;
    });
  };

  handleViewRoom = (room) => {
    this.setState({ selectedRoom: room });
  };

  searchRoomByRoomNumber = (roomNumber) => {
    const room = LISTROOMS.find((room) => room.roomName === roomNumber);
    return room;
  };
  

  render() {
    const sortRoomsByTags = (rooms) => {
        return rooms.sort((a, b) => {
          if (a.tagIds.length === 0 && b.tagIds.length > 0) {
            return 1; // Phòng a không có tag, nên sắp sau cùng
          }
          if (a.tagIds.length > 0 && b.tagIds.length === 0) {
            return -1; // Phòng b không có tag, nên sắp sau cùng
          }
          if (a.picturesURL.length === 0 && b.picturesURL.length > 0) {
            return 1; // Phòng a không có hình ảnh, nên sắp sau cùng
          }
          if (a.picturesURL.length > 0 && b.picturesURL.length === 0) {
            return -1; // Phòng b không có hình ảnh, nên sắp sau cùng
          }
          return 0; // Cả hai phòng đều có hoặc không có tag/hình ảnh
        });
      };
      
    const { searchTerm, searchResult, minPrice, maxPrice, filteredRooms, selectedRoom, tagSearch } = this.state;
    const sortedRooms = sortRoomsByTags(filteredRooms);

    return (
      <div>
        <h1>Room Search</h1>
        <div>
          <input
            type="text"
            placeholder="Tìm kiếm phòng theo số phòng"
            value={searchTerm}
            onChange={this.handleSearchInputChange}
          />
          <button onClick={this.handleSearch}>Tìm kiếm</button>
        </div>
        <div>
  <input
    type="text"
    placeholder="Tìm kiếm theo tag"
    value={tagSearch}
    onChange={this.handleTagSearchChange}
  />
  <button onClick={this.handleSearch}>Tìm kiếm</button>
</div>
        <div>
          <label htmlFor="minPrice">Giá tối thiểu:</label>
          <input
            type="number"
            id="minPrice"
            value={minPrice}
            onChange={this.handleMinPriceChange}
          />
        </div>
        <div>
          <label htmlFor="maxPrice">Giá tối đa:</label>
          <input
            type="number"
            id="maxPrice"
            value={maxPrice}
            onChange={this.handleMaxPriceChange}
          />
        </div>
        <div>

        {searchResult ? (
  <div>
    <h2>Thông tin phòng {searchResult.roomName}</h2>
    <p>Địa chỉ: {searchResult.address}</p>
    <p>Mô tả: {searchResult.description}</p>
    <p>Diện tích: {searchResult.acreage}</p>
    <p>Giá: {searchResult.price}</p>
    <p>Số người tối đa: {searchResult.maxQuantity}</p>
    <p>Trạng thái: {searchResult.status}</p>
    {searchResult.picturesURL.length > 0 && (
      <div>
        <h3>Hình ảnh</h3>
        {searchResult.picturesURL.map((url, index) => (
          <img key={index} src={url} alt={`Hình ${index + 1}`} />
        ))}
      </div>
    )}
  </div>
) : (
  <div>
    <h2>Danh sách phòng (theo giá)</h2>
    <ul>
      {sortedRooms.map((room) => (
        <li key={room.room_id}>
          <strong>{room.roomName}</strong> - Giá: {room.price}
          <button onClick={() => this.handleViewRoom(room)}>Xem phòng</button>
        </li>
      ))}
    </ul>
  </div>
)}

        </div>
        {selectedRoom && (
  <div>
    <h2>Thông tin chi tiết của phòng {selectedRoom.roomName}</h2>
    <p>Địa chỉ: {selectedRoom.address}</p>
    <p>Mô tả: {selectedRoom.description}</p>
    <p>Diện tích: {selectedRoom.acreage}</p>
    <p>Giá: {selectedRoom.price}</p>
    <p>Số người tối đa: {selectedRoom.maxQuantity}</p>
    <p>Trạng thái: {selectedRoom.status}</p>
    
    {selectedRoom.picturesURL.length > 0 && (
      <div>
        <h3>Hình ảnh</h3>
        {selectedRoom.picturesURL.map((url, index) => (
          <img key={index} src={url} alt={`Hình ${index + 1}`} />
        ))}
      </div>
    )}
    {selectedRoom.tagIds.length > 0 && (
      <div>
        <h3>Tags</h3>
        <ul>
          {selectedRoom.tagIds.map((tagIds, index) => (
            <li key={index}>
              {selectedRoom.tags && selectedRoom.tags[tagIds] ? selectedRoom.tags[tagIds] : "Tag không tồn tại"}
            </li>
          ))}
        </ul>
      </div>
    )}
  </div>
        )}
        </div>
    )
        };
    }
        

export default RoomSearch;
