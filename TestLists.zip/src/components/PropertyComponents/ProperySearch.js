import React, { Component } from 'react';
import {LISTPROPERTY} from './listProperty';

class PropertySearch extends Component {
  constructor() {
    super();
    this.state = {
      searchTerm: '',
      searchResult: null, // Sử dụng null thay vì một mảng
    };
  }

  handleSearchInputChange = (event) => {
    this.setState({ searchTerm: event.target.value });
  };

  handleSearch = () => {
    const { searchTerm } = this.state;

    // Thực hiện tìm kiếm sử dụng mã JavaScript đã cung cấp ở trước
    const searchResult = this.searchPropertyByName(searchTerm);

    this.setState({ searchResult });
  };

  // Hàm tìm kiếm bất động sản theo tên
  searchPropertyByName = (propertyName) => {
    // Sử dụng find để tìm bất động sản có tên khớp với tìm kiếm
    const property = LISTPROPERTY.find(property => property.propertyName === propertyName);

    return property;
  };

  render() {
    const { searchTerm, searchResult } = this.state;

    return (
      <div>
        <h1>Property Search</h1>
        <div>
          <input
            type="text"
            placeholder="Tìm kiếm theo tên"
            value={searchTerm}
            onChange={this.handleSearchInputChange}
          />
          <button onClick={this.handleSearch}>Tìm kiếm</button>
        </div>
        <div>
          {searchResult ? (
            <div>
              <h2>Thông tin bất động sản {searchResult.propertyName}</h2>
              <p>Địa chỉ: {searchResult.address}</p>
              <p>Ngày đăng ký: {searchResult.registrationDate}</p>
              <p>Đơn vị cho thuê: {searchResult.unitForRent}</p>
              <p>Chức năng bất động sản: {searchResult.propertyRole}</p>
              <p>Chủ sở hữu: {searchResult.owner}</p>
              <p>Email chủ sở hữu: {searchResult.ownerEmail}</p>
              <p>Trạng thái: {searchResult.status}</p>
              {searchResult.pictureUrl && (
                <div>
                  <h3>Hình ảnh</h3>
                  <img src={searchResult.pictureUrl} alt="Hình ảnh bất động sản" />
                </div>
              )}
            </div>
          ) : (
            <p>Không tìm thấy bất động sản.</p>
          )}
        </div>
      </div>
    );
  }
}

export default PropertySearch;
